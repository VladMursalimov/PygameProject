import pygame
import sys
import os
import random


pygame.init()
running = True
WIDTH, HEIGHT = 1200, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
clock = pygame.time.Clock()
FPS = 50
### движение мобов
mobmove = pygame.USEREVENT + 1
mobspawn = pygame.USEREVENT + 4
hillspawn = pygame.USEREVENT + 5

pygame.time.set_timer(mobmove, 1000)
mobshot = pygame.USEREVENT + 2
time1 = pygame.USEREVENT + 3
pygame.time.set_timer(time1, 100)
flag = 0
kills = 0


### загружает картинки
def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if name != 'background.png' and name != 'bullet.png':
        image = pygame.transform.scale(image, (50, 50))
    elif name == 'bullet.png':
        image = pygame.transform.scale(image, (15, 15))
    if colorkey is not None:
        image = image.convert()
        colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)

    image = image.convert_alpha()
    return image


tile_images = {
    'wall': load_image('box.png'),
    'empty': pygame.Surface((50, 50))
}
player_image = load_image('hero.png')
mob_image = load_image('mob.png')
bulletimg = load_image('bullet.png', -1)

tile_width = tile_height = 50

###класс блока стены или пустого
class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(sprite_group)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)
        if tile_type == 'wall':
            self.add(wall_group)

###класс игрока
class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(hero_group)
        self.image = player_image
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)
        self.pos = (pos_x, pos_y)
        self.posf = self.pos
        self.lives = 10

    def move(self, x, y):
        self.pos = (x, y)
        self.posf = self.pos
        self.rect = self.image.get_rect().move(
            tile_width * self.pos[0], tile_height * self.pos[1])

    def check(self):
        #убийство игрока если в него попала пуля
        if pygame.sprite.spritecollideany(self, bulletsmob):
            pygame.sprite.spritecollide(self, bulletsmob, True)
            hit.play()
            hero1.lives -= 1
            if hero1.lives == 0:
                hero1.kill()
        if pygame.sprite.spritecollideany(self, hillgroup):
            hero1.lives += 2
            pygame.sprite.spritecollide(self, hillgroup, True)
            if hero1.lives > 10:
                hero1.lives = 10


###класс пули
class Bullet(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y, dir):
        super().__init__(bullets)
        self.image = pygame.Surface((5, 15))
        self.image.fill((255, 255, 0))
        self.rect = self.image.get_rect()
        self.rect.bottom = pos_y
        self.rect.centerx = pos_x
        self.dir = dir

    def move(self):
        if self.dir == 'down':
            self.rect.y += 20
        elif self.dir == 'up':
            self.rect.y -= 10
        elif self.dir == 'left':
            self.rect.x -= 10
        elif self.dir == 'right':
            self.rect.x += 10
        # убить, если он заходит за часть экрана
        if self.rect.x < 0 or self.rect.x > WIDTH \
                or self.rect.y < 0 or self.rect.y > HEIGHT:
            self.kill()
        if pygame.sprite.spritecollideany(self, wall_group):
            self.kill()


class BulletMob(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y, dir):
        super().__init__(bulletsmob)
        self.image = bulletimg

        self.rect = self.image.get_rect()
        self.rect.bottom = pos_y
        self.rect.centerx = pos_x
        self.dir = dir

    def move(self):
        if self.dir == 'down':
            self.rect.y += 10
        elif self.dir == 'up':
            self.rect.y -= 10
        elif self.dir == 'left':
            self.rect.x -= 10
        elif self.dir == 'right':
            self.rect.x += 10
        # убить, если он заходит за часть экрана
        if self.rect.x < 0 or self.rect.x > WIDTH \
                or self.rect.y < 0 or self.rect.y > HEIGHT:
            self.kill()
        if pygame.sprite.spritecollideany(self, wall_group):
            self.kill()

class Hill(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(hillgroup)
        self.image = pygame.Surface((30, 30))
        self.image.fill((255, 0, 0))
        self.rect = self.image.get_rect().move(
            tile_width * pos_x + 15, tile_height * pos_y + 5)
        self.rect.bottom = pos_y * tile_height + 45
        self.rect.centerx = pos_x * tile_width + 25
        self.pos = (pos_x, pos_y)

    def move(self):
        self.directon = random.choice(['u', 'l', 'r'])
        if self.directon == 'u':
            self.rect.y -= 50
            if pygame.sprite.spritecollideany(self, wall_group):
                self.rect.y += 50
        if self.directon == 'l':
            if 0 < self.rect.x - 50 < WIDTH:
                self.rect.x -= 50
                if pygame.sprite.spritecollideany(self, wall_group):
                    self.rect.x += 50
        if self.directon == 'r':
            if 0 < self.rect.x + 50 < WIDTH:
                self.rect.x += 50
                if pygame.sprite.spritecollideany(self, wall_group):
                    self.rect.x -= 50



###класс моба
class Mob(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(mobs_group)
        self.image = mob_image
        self.rect = self.image.get_rect().move(
            tile_width * pos_x + 15, tile_height * pos_y + 5)
        self.rect.bottom = pos_y * tile_height + 45
        self.rect.centerx = pos_x * tile_width + 25
        self.pos = (pos_x, pos_y)

#проверка на убийство игрока или самого моба
    def check(self):
        global kills
        if pygame.sprite.spritecollideany(self, bullets):
            #так же убивает пулю, если она убивает моба
            pygame.sprite.spritecollide(self, bullets, True)
            self.kill()
            kills += 1
        if pygame.sprite.spritecollideany(self, hero_group):
            hero1.lives -= 1
            if hero1.lives == 0:
                hero1.kill()

#движение в рандомном направлении
    def move(self):
        if self.rect.y <= 50:
            hero1.lives = 0
            hero1.kill()
        self.directon = random.choice(['u', 'l', 'r'])
        if self.directon == 'u':
            self.rect.y -= 50
            if pygame.sprite.spritecollideany(self, wall_group):
                self.rect.y += 50
        if self.directon == 'd':
            if 0 < self.rect.y + 50 < HEIGHT:
                self.rect.y += 50
                if pygame.sprite.spritecollideany(self, wall_group):
                    self.rect.y -= 50
        if self.directon == 'l':
            if 0 < self.rect.x - 50 < WIDTH:
                self.rect.x -= 50
                if pygame.sprite.spritecollideany(self, wall_group):
                    self.rect.x += 50
        if self.directon == 'r':
            if 0 < self.rect.x + 50 < WIDTH:
                self.rect.x += 50
                if pygame.sprite.spritecollideany(self, wall_group):
                    self.rect.x -= 50

    def shot(self):
        if self.rect.y >= 50:
            mobshoot.play()
        dir = 'up'
        mobbullet = BulletMob(self.rect.x + 25, self.rect.y + 25, dir)


player = None
running = True
clock = pygame.time.Clock()
sprite_group = pygame.sprite.Group()
hero_group = pygame.sprite.Group()
bullets = pygame.sprite.Group()
mobs_group = pygame.sprite.Group()
wall_group = pygame.sprite.Group()
bulletsmob = pygame.sprite.Group()
hillgroup = pygame.sprite.Group()

#Sound
shoot = pygame.mixer.Sound('data/shoot.wav')
mobshoot = pygame.mixer.Sound('data/mobshoot.wav')
hit = pygame.mixer.Sound('data/hit.wav')
win = pygame.mixer.Sound('data/win.wav')
lose = pygame.mixer.Sound('data/lose.wav')
menumusic = pygame.mixer.Sound('data/menumusic.mp3')
shoot.set_volume(0.2)
mobshoot.set_volume(0.2)
hit.set_volume(0.2)


def terminate():
    pygame.quit()
    sys.exit

#начальный экран
def start_screen():
    global flag
    menumusic.play(-1)
    menumusic.set_volume(0.2)
    intro_text = ["Проект по Pygame",
                  "Для начала нажмите любую кнопку",
                  '', '', '',
                  'Выбор сложности:',
                  '1.EZ',
                  '2.DEFAULT',
                  '3.HARD',
                  '4.Бесконечный режим']

    fon = pygame.transform.scale(load_image('background.png'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 50)
    text_coord = 200
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('yellow'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 400
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)


#ожидание клика
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    pygame.time.set_timer(mobshot, 2000)
                    pygame.time.set_timer(mobmove, 1000)
                    return
                elif event.key == pygame.K_2:
                    pygame.time.set_timer(mobshot, 1000)
                    pygame.time.set_timer(mobmove, 500)
                    return
                elif event.key == pygame.K_3:
                    pygame.time.set_timer(mobshot, 600)
                    pygame.time.set_timer(mobmove, 300)
                    return
                elif event.key == pygame.K_4:
                    pygame.time.set_timer(hillspawn, 70000)
                    pygame.time.set_timer(mobspawn, 2000)
                    pygame.time.set_timer(mobshot, 2000)
                    pygame.time.set_timer(mobmove, 1000)
                    flag = 4
                    return
        pygame.display.flip()


#тоже самое что и начальный, только конечный
def end_screen():
    lose.play()
    intro_text = ['Game over',
                  'Чтобы продолжить нажмите',
                  'любую кнопку']

    fon = pygame.transform.scale(load_image('background.png'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 50)
    text_coord = 200
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('yellow'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 400
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return
        pygame.display.flip()
        clock.tick(FPS)

def final_screen():
    win.play()
    intro_text = ['Победа']

    fon = pygame.transform.scale(load_image('background.png'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('yellow'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 550
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        pygame.display.flip()
        clock.tick(FPS)

def end_screen2():
    razmer = 0
    win.play()
    intro_text = ['Победа',
                  'Чтобы продолжить нажмите',
                  'любую кнопку']

    fon = pygame.transform.scale(load_image('background.png'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if razmer >= 1200:
                return
        razmer += 10
        screen.blit(fon, (0, 0))
        loadingimg = load_image('herocopy.png')
        pygame.draw.rect(screen, pygame.Color('white'), (razmer + 5, 395, 1200, 10))
        screen.blit(loadingimg, (razmer, 375))

        pygame.display.flip()
        clock.tick(FPS)


#преобразует файл уровня в список
def load_level(filename):
    filename = "data/" + filename
    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]
    max_width = max(map(len, level_map))
    return list(map(lambda x: list(x.ljust(max_width, '.')), level_map))

#объявляет переменные игрока, клеток и мобов

def generate_level(level):
    new_player, x, y = None, None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '.':
                Tile('empty', x, y)
            elif level[y][x] == '#':
                Tile('wall', x, y)
            elif level[y][x] == '@':
                Tile('empty', x, y)
                new_player = Player(x, y)
                level[y][x] = "."
            elif level[y][x] == '$':
                Tile('empty', x, y)
                new_mob = Mob(x, y)
                level[y][x] = '.'
    return new_player, x, y

#проверяет и двигает персонажа
def move(hero, movement):
    x, y = hero.pos
    if movement == "up":
        if y > 0 and level_map[y - 1][x] != "#":
            hero.move(x, y - 1)
    elif movement == "down":
        if y < max_y - 1 and level_map[y + 1][x] != "#":
            hero.move(x, y + 1)
    elif movement == "left":
        if x > 0 and level_map[y][x - 1] != "#":
            hero.move(x - 1, y)
    elif movement == "right":
        if x < max_x - 1 and level_map[y][x + 1] != "#":
            hero.move(x + 1, y)


bullet = Bullet(0, 0, 'up')
start_screen()
if flag == 4:
    level_map = load_level('ever.txt')
else:
    level_map = load_level("level1.txt")
hero1, max_x, max_y = generate_level(level_map)
dir = 'up'
sec = 0
lstsec = '0'
leveln = 1
#сам цикл
while running:
    #если перс умер
    if hero1.lives <= 0:
        hero1.kill()
        end_screen()
        bulletsmob = pygame.sprite.Group()
        bullets = pygame.sprite.Group()
        hillgroup = pygame.sprite.Group()
        mobs_group = pygame.sprite.Group()
        if flag == 4:
            level_map = load_level('ever.txt')
        else:
            level_map = load_level("level{}.txt".format((str(leveln))))
        hero1, max_x, max_y = generate_level(level_map)
        lstsec = '0'
        sec = 0
    if not mobs_group:
        leveln += 1
        if leveln == 6:
            final_screen()
            pygame.quit()
        else:
            hero1.kill()
            end_screen2()
            bulletsmob = pygame.sprite.Group()
            bullets = pygame.sprite.Group()
            hillgroup = pygame.sprite.Group()
            mobs_group = pygame.sprite.Group()
            level_map = load_level("level{}.txt".format(str(leveln)))
            hero1, max_x, max_y = generate_level(level_map)
            lstsec = '0'
            sec = 0
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == hillspawn:
            newhill = Hill(random.randint(0, 22), 16)
        #двигает мобов
        if event.type == mobspawn:
            newmob = Mob(random.randint(0, 20), 16)
        if event.type == mobmove:
            for j in mobs_group:
                j.move()
            for k in hillgroup:
                k.move()
        if event.type == mobshot:
            for j in mobs_group:
                j.shot()
        #двигает персов
        elif event.type == pygame.KEYDOWN:
            #if event.key == pygame.K_UP:
            #    move(hero1, "up")
            #    dir = 'up'
            #elif event.key == pygame.K_DOWN:
            #    move(hero1, "down")
            #    dir = 'down'
            if event.key == pygame.K_LEFT:
                move(hero1, "left")
                dir = 'left'
            elif event.key == pygame.K_RIGHT:
                move(hero1, "right")
                dir = 'right'
            elif event.key == pygame.K_SPACE:
                pygame.time.set_timer(mobmove, 0)
            elif event.key == pygame.K_r:
                pygame.time.set_timer(mobmove, 1000)
        #создает пули
        if event.type == pygame.MOUSEBUTTONDOWN:
            if len(bullets.sprites()) < 4:
                shoot.play()
                dir = 'down'
                bullet = Bullet(hero1.posf[0] * 50 + 25, hero1.posf[1] * 50 + 25, dir)
    #двигает пули
    for i in bullets:
        i.move()
    for j in mobs_group:
        j.check()
    for i in bulletsmob:
        i.move()
    hero1.check()
    screen.fill((0, 0, 0))
    fon = pygame.transform.scale(load_image('background.png'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    wall_group.draw(screen)
    bullets.draw(screen)
    bulletsmob.draw(screen)
    hero_group.draw(screen)
    mobs_group.draw(screen)
    hillgroup.draw(screen)
    font = pygame.font.Font(None, 50)
    string_rendered = font.render(str(hero1.lives), False, pygame.Color('yellow'))
    screen.blit(string_rendered, (50, 50))
    string_rendered = font.render(str(kills), False, pygame.Color('yellow'))
    screen.blit(string_rendered, (1100, 50))
    image1 = pygame.Surface((100, 10))
    image1.fill((255, 0, 0))
    rect1 = image1.get_rect()
    rect1.bottom = 0
    rect1.centerx = 0
    pygame.draw.rect(screen, pygame.Color('white'), (0, 0, 1200, 50))
    pygame.draw.rect(screen, pygame.Color('red'), (0, 0, hero1.lives * 120, 50))
    sec += 1
    if sec % 100 == 0:
        lstsec = str(sec // 100)
        string_rendered = font.render(str(sec // 100), False, pygame.Color('black'))
        screen.blit(string_rendered, (1000, 50))
    else:
        string_rendered = font.render(lstsec, False, pygame.Color('black'))
        screen.blit(string_rendered, (1000, 50))
    pygame.display.flip()
    clock.tick(FPS)
    pygame.display.flip()
pygame.quit()